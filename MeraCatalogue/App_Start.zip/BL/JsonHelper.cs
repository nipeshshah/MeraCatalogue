﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MeraCatalogue.BL
{
    public class JsonHelper
    {

    }
}