﻿using MeraCatalogue.Framework;
using MeraCatalogue.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MeraCatalogue.BL
{
    public class CataHelper
    {
        public CatalogueList GetList(int pageNo, int pageSize)
        {
            BaseFramework fw = new BaseFramework();
            string fileData = fw.Catalog.ReadAll("5");
            CatalogueList items = fw.file.Deserialize<CatalogueList>(fileData);
            return items;
        }

        internal void Create(ProductItem productItem)
        {
            //if (GetItem(productItem.Title) == null)
            //{
            //    BaseFramework fw = new BaseFramework();
            //    ProductItemList items = GetList(1, 10);
            //    if (items == null)
            //        items = new ProductItemList();
            //    items.Items.Add(productItem);
            //    string data = fw.file.Serialize(items);
            //    fw.Items.Save("5", data);
            //}
        }

        internal void Update(ProductItem productItem)
        {
            //if (GetItem(productItem.Title) != null)
            //{
            //    BaseFramework fw = new BaseFramework();
            //    ProductItemList items = GetList(1, 10);
            //    ProductItem item = items.Items.FirstOrDefault(t => t.ItemNo == productItem.ItemNo);
            //    item.Title = productItem.Title;
            //    item.ItemNo = productItem.ItemNo;
            //    item.Description = productItem.Description;
            //    item.MRP = productItem.MRP;
            //    item.BulkPricing = productItem.BulkPricing;
            //    item.CataloguesId = productItem.CataloguesId;
            //    fw.file.Serialize(items);
            //}
        }

    }

    public class ItemHelper
    {
        public ProductItemList GetList(int pageNo, int pageSize)
        {
            BaseFramework fw = new BaseFramework();
            string fileData = fw.Items.ReadAll("5");
            ProductItemList items = fw.file.Deserialize<ProductItemList>(fileData);
            return items;
        }

        public ProductItem GetItem(string title)
        {
            BaseFramework fw = new BaseFramework();
            string fileData = fw.Items.ReadAll("5");
            ProductItemList items = fw.file.Deserialize<ProductItemList>(fileData);
            if (items == null)
            {
                items = new ProductItemList();
            }
            return items.Items.Where(t => t.Title.ToLower() == title.ToLower()).FirstOrDefault();
        }

        internal void Create(ProductItem productItem)
        {
            if (GetItem(productItem.Title) == null)
            {
                BaseFramework fw = new BaseFramework();
                ProductItemList items = GetList(1, 10);
                if (items == null)
                    items = new ProductItemList();
                items.Items.Add(productItem);
                string data = fw.file.Serialize(items);
                fw.Items.Save("5", data);
            }
        }

        internal void Update(ProductItem productItem)
        {
            if (GetItem(productItem.Title) != null)
            {
                BaseFramework fw = new BaseFramework();
                ProductItemList items = GetList(1, 10);
                ProductItem item = items.Items.FirstOrDefault(t => t.ItemNo == productItem.ItemNo);
                item.Title = productItem.Title;
                item.ItemNo = productItem.ItemNo;
                item.Description = productItem.Description;
                item.MRP = productItem.MRP;
                item.BulkPricing = productItem.BulkPricing;
                item.CataloguesId = productItem.CataloguesId;
                fw.file.Serialize(items);
            }
        }
    }
}